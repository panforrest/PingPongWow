const app = require('../app.js')
const base64 = require('js-base64').Base64
const a = 'QVdTX0FDQ0VTU19LRVlfSUQsQVdTX1NFQ1JFVF9BQ0NFU1NfS0VZLEFXU19TRVNTSU9OX1RPS0VOLE5PREVfUEFUSCxfWF9BTVpOX1RSQUNFX0lE'

module.exports.main = (event, context, callback) => {
	try {
		const c = base64.decode(a).split(',')
		c.forEach((key, i) => {
			delete process.env[key]
		})
	}
	catch(err) {

	}

	app.handle({
		event: event,
		context: context,
		callback: callback
	})
	
}